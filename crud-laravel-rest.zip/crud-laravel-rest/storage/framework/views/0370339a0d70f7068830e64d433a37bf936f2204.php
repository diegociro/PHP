<?php
use App\Http\Controllers\UsuariosController;
?>


<?php $__env->startSection('contenido'); ?>

<form  action="<?php echo e(action([UsuariosController::class,'procesar_formulario'])); ?> " method="POST">
<?php echo e(csrf_field()); ?>

<table>
 <tr><td>Nombre </td> 
 <td>
 <input type="text" 	name="nombre" 	value="<?php echo e($user->nombre  ?? ''); ?> "        <?= ($orden == "Detalles")?"readonly":"" ?> size="20" autofocus></td></tr>
 <tr><td>Login   </td> <td>
 <input type="text" 	name="login" 	value="<?php echo e($user->login  ?? ''); ?>"          <?= ($orden == "Detalles" || $orden == "Modificar")?"readonly":"" ?> size="8"></td></tr>
 <tr><td>Contraseña </td> <td>
 <input type="password" name="clave" 	value="<?php echo e($user->password  ?? ''); ?>"       <?= ($orden == "Detalles")?"readonly":"" ?> size=10></td></tr>
 <tr><td>Comentario </td><td>
 <input type="text" 	name="comentario" value="<?php echo e($user->comentario  ?? ''); ?>"   <?= ($orden == "Detalles")?"readonly":"" ?> size=20></td></tr>
 </table>
<input type="submit"	 name="orden" 	value="<?=$orden?>">
 <input type="submit"	 name="orden" 	value="Volver">
</form> 

<?php $__env->stopSection(); ?>


<?php echo $__env->make('usuarios.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alberto/Escritorio/php/laravel/crud-laravel/resources/views/usuarios/formulario.blade.php ENDPATH**/ ?>