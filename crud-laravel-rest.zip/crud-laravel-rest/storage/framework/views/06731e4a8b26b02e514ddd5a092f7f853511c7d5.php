<!-- Plantilla principal -->
<?php
use App\Http\Controllers\UsuariosController;
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>CRUD DE USUARIOS</title>
<link href="<?php echo e(URL::asset('css/default.css')); ?>" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo e(URL::asset('js/funciones.js')); ?>"></script>
</head>
<body>
<div id="container" >
<div id="header">
<h1>GESTIÓN DE USUARIOS con Laravel + BD</h1>
</div>
<div id="content">
    <?php echo $__env->yieldContent('contenido'); ?>

</div>
</div>
</body>
<?php /**PATH /home/alberto/Escritorio/php/laravel/crud-laravel/resources/views/usuarios/principal.blade.php ENDPATH**/ ?>