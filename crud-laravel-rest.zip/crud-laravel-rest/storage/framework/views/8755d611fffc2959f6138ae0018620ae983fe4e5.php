<?php
use App\Http\Controllers\UsuariosController;
?>


<?php $__env->startSection('contenido'); ?>

<?php
$titulos = [ "Nombre","login","Password","Comentario"];
?>
<table>
<tr>
<?php for($j=0; $j < count($titulos); $j++): ?>
  <th><?php echo e($titulos[$j]); ?></th>
<?php endfor; ?>
</tr>
<?php $__currentLoopData = $tuser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
  <tr>
  <td><?php echo e($user->nombre); ?></td>
  <td><?php echo e($user->login); ?></td>
  <td><?php echo e($user->password); ?></td>
  <td><?php echo e($user->comentario); ?></td>
  <td><a href="<?php echo e(action([UsuariosController::class,'borrar'],['id' => $user->login])); ?>" 
    onclick=" return confirm('¿Quieres eliminar el usuario:  <?php echo e($user->login); ?>')">Borrar</a></td>
  <td><a href="<?php echo e(action([UsuariosController::class,'modificar_formulario'],['id' => $user->login])); ?>">Modificar</a></td>
  <td><a href="<?php echo e(action([UsuariosController::class,'detalles'],['id' => $user->login])); ?>" >Detalles</a></td>
  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<form  action = "<?php echo e(action([UsuariosController::class,'nuevo_formulario'])); ?> ">
<input type="submit" name="orden" value="Nuevo">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('usuarios.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alberto/Escritorio/php/laravel/crud-laravel/resources/views/usuarios/listar.blade.php ENDPATH**/ ?>